/* ============================================
   App Logic - Navigation & Counter Animations
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initCounterAnimations();
  initCharts();
});

/* ---- Navigation ---- */
function initNavigation() {
  // In-page tabs navigate between dashboards
  document.querySelectorAll('.page-tab[data-tab]').forEach(tab => {
    tab.addEventListener('click', () => {
      switchDashboard(tab.dataset.tab);
    });
  });

  // Also support console tab click
  document.querySelectorAll('.console-tab[data-tab]').forEach(tab => {
    tab.addEventListener('click', () => {
      switchDashboard(tab.dataset.tab);
    });
  });
}

function switchDashboard(target) {
  const dashboards = document.querySelectorAll('.dashboard');
  dashboards.forEach(d => {
    d.classList.remove('active');
    d.style.animation = 'none';
  });

  const targetDash = document.getElementById(target);
  if (targetDash) {
    targetDash.classList.add('active');
    void targetDash.offsetWidth;
    targetDash.style.animation = '';
    animateCountersIn(targetDash);
  }

  // Update console tab label
  const consoleTab = document.querySelector('.console-tab');
  if (consoleTab) {
    const label = targetDash?.querySelector('.page-title')?.textContent || 'Dashboard';
    consoleTab.querySelector('.console-tab-label').textContent = label;
  }
}

/* ---- Counter Animations ---- */
function initCounterAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-target]').forEach(el => observer.observe(el));
}

function animateCountersIn(container) {
  container.querySelectorAll('[data-target]').forEach(el => animateCounter(el));
}

function animateCounter(el) {
  const target = parseFloat(el.dataset.target);
  const suffix = el.dataset.suffix || '';
  const isDecimal = el.dataset.decimal === 'true';
  const duration = 1000;
  const start = performance.now();

  function update(now) {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = target * eased;

    if (isDecimal) {
      el.textContent = current.toFixed(2) + suffix;
    } else if (target >= 1000) {
      el.textContent = Math.round(current).toLocaleString('fr-FR') + suffix;
    } else {
      el.textContent = Math.round(current) + suffix;
    }

    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      if (isDecimal) el.textContent = target.toFixed(2) + suffix;
      else if (target >= 1000) el.textContent = Math.round(target).toLocaleString('fr-FR') + suffix;
      else el.textContent = Math.round(target) + suffix;
    }
  }

  requestAnimationFrame(update);
}
