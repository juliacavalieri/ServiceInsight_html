/* ============================================
   Chart.js - Service Insights Dashboard
   ============================================ */

const SF = {
  negative: '#BA0517',
  warning: '#DD7A01',
  positive: '#2E844A',
  blue: '#0250D9',
  blueLight: '#0B6FCC',
  purple: '#7B48AA',
  gray: '#C9C9C9',
  teal: '#0D9DDA',
  pink: '#E3066A',
  green2: '#41B658',
  orange: '#FE8F1D',
};

Chart.defaults.font.family = "'SF Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
Chart.defaults.font.size = 11;
Chart.defaults.color = '#5C5C5C';

function initCharts() {
  initSparklines();
  initChannelPie();
  initStatusBar();
  initRoutingChart();
  initQueueChart();
  initVolumeTrend();
}

/* ---- KPI Sparklines (no fill, no axes, thin line) ---- */
function initSparklines() {
  const sparkOpts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { enabled: false } },
    scales: { x: { display: false }, y: { display: false } },
    elements: { point: { radius: 0 }, line: { tension: 0.4, borderWidth: 1.5 } }
  };

  const s1 = document.getElementById('spark1');
  if (s1) {
    new Chart(s1, {
      type: 'line',
      data: {
        labels: ['', '', '', '', '', '', '', '', ''],
        datasets: [{
          data: [9800, 10200, 10500, 10100, 11000, 11500, 11800, 12200, 12546],
          borderColor: SF.positive,
          fill: false
        }]
      },
      options: sparkOpts
    });
  }

  const s5 = document.getElementById('spark5');
  if (s5) {
    new Chart(s5, {
      type: 'line',
      data: {
        labels: ['', '', '', '', '', '', '', '', ''],
        datasets: [{
          data: [14200, 14800, 15100, 15500, 15800, 16200, 16600, 16900, 17200],
          borderColor: SF.teal,
          fill: false
        }]
      },
      options: sparkOpts
    });
  }
}

/* ---- Volume par Canal (horizontal bar) ---- */
function initChannelPie() {
  const ctx = document.getElementById('channelPieChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Cas', 'Lead', 'Chat', 'Appel vocal', 'Personnalisé'],
      datasets: [{
        data: [5372, 3278, 2522, 1374, 800],
        backgroundColor: [SF.blue, SF.pink, SF.positive, SF.teal, SF.orange],
        borderRadius: 3,
        barThickness: 14
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: { display: false },
        y: { grid: { display: false }, ticks: { font: { size: 10 } } }
      }
    }
  });
}

/* ---- Volume par Statut ---- */
function initStatusBar() {
  const ctx = document.getElementById('statusBarChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Assigné', 'Annulé', 'Fermé'],
      datasets: [{
        data: [8500, 1200, 3846],
        backgroundColor: [SF.blue, SF.pink, SF.positive],
        borderRadius: 3,
        barThickness: 28
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false },
        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
      }
    }
  });
}

/* ---- Efficacité du Routage (stacked horizontal bar) ---- */
function initRoutingChart() {
  const ctx = document.getElementById('routingChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Cas', 'Lead', 'Chat', 'Appel vocal', 'Personnalisé'],
      datasets: [
        { label: 'Réassigné', data: [3200, 1800, 1500, 800, 400], backgroundColor: SF.blue, borderRadius: 2, barThickness: 14 },
        { label: 'Non réassigné', data: [2172, 1478, 1022, 574, 400], backgroundColor: SF.pink, borderRadius: 2, barThickness: 14 }
      ]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { usePointStyle: true, padding: 8, font: { size: 10 } } }
      },
      scales: {
        x: { stacked: true, display: false },
        y: { stacked: true, grid: { display: false }, ticks: { font: { size: 10 } } }
      }
    }
  });
}

/* ---- Volume par File d'Attente (horizontal bar) ---- */
function initQueueChart() {
  const ctx = document.getElementById('queueChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Cas', 'Lead', 'Chat', 'Appel vocal'],
      datasets: [{
        data: [5372, 3278, 2522, 1374],
        backgroundColor: SF.blue,
        borderRadius: 3,
        barThickness: 18
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { display: false },
        y: { grid: { display: false }, ticks: { font: { size: 10 } } }
      }
    }
  });
}

/* ---- Tendance du Volume (line chart, no fill) ---- */
function initVolumeTrend() {
  const ctx = document.getElementById('volumeTrendChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['2025', '2026', '2027'],
      datasets: [{
        label: 'Total Éléments',
        data: [8200, 12546, 11000],
        borderColor: SF.blue,
        fill: false,
        tension: 0.4,
        pointRadius: 3,
        pointHoverRadius: 5,
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'left', labels: { usePointStyle: true, font: { size: 10 } } }
      },
      scales: {
        y: { display: false },
        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
      }
    }
  });
}
